# Firebase config and initialization using pyrebase4
