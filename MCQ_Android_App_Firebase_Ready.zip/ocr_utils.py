# OCR parsing module
