Firebase-ready Kivy Android App
1. Replace firebase_config.py with your own credentials.
2. Add pyrebase4 to buildozer.spec: requirements = python3,kivy,pyrebase4,...
3. Build APK with Buildozer.
